import socket
import re

def res(a,b):
    pp.send("? %d %d\n"%(a,b))
    return int(pp.recv(4096))

def level(s):
    r = re.findall("Level (\d+) \: n \= (\d+)",s)
    print s
    if len(r) == 1:
        return int(r[0][1])

def loop(a,b,n):
    c = (a+b)/2
    n1 = res(a,c)
    print "a: %d c: %d n1: %d n:%d" % (a,c,n1,n) 
    if n1 == n:
        if not last(a,c,n):
            loop(a,c,n)
    elif n1 == 0:
        if not last(c,b,n):
            loop(c,b,n)
    else:
        if not last(a,c,n1):
            loop(a,c,n1)
        if not last(c,b,n-n1):
            loop(c,b,n-n1)

def last(a,b,n):
    if b-a==1:
        for i in range(n):
            answer.append(a)
        return True
    return False

pp  = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
pp.settimeout(3)
ppc = pp.connect(("47.89.18.224", 10011))

for i in range(0,15):
    answer = []
    n = level(pp.recv(4096))
    a,b = 0,1024
    loop(a,b,n)
    answer.sort()
    print answer
    sss = '! '+' '.join([str(i) for i in answer])+'\n'
    print sss
    pp.send(sss)
    result = pp.recv(4096)
    if '-' in result:
        print 'n = %d success, next level' % (n)
    else:
        print result




        
    

