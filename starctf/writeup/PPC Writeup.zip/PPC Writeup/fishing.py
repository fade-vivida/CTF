import socket
import hashlib
import re
import string
import subprocess

def ticket(ha):
    u = string.digits+string.ascii_letters
    ss = re.findall('sha256\(xxxx\+(.*)\) \=\=([a-z0-9]*)',ha)
    if len(ss) == 1:
        key, sha = ss[0]
        for a in u:
            for b in u:
                for c in u:
                    for d in u:
                        if hashlib.sha256(a+b+c+d+key).hexdigest() == sha:
                            return a+b+c+d


class chess():
    fen   = ''
    fen0  = ''
    moves = ['']
    pp = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    def __init__(self):
        self.count = 0
        self.pp  = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.pp.settimeout(3)
        self.pp.connect(("47.89.11.82", 10012))

        ha = self.pp.recv(4096)
        self.pp.send(ticket(ha))
        ss = self.pp.recv(4096)
        while 'continue:' not in ss:
            ss = self.pp.recv(4096)
            
        self.pp.send('\n')
        print '[+] get ticket !'

    @staticmethod
    def print_fen(fen):
        #print len(fen),fen
        if len(fen)!=64:
            exit(0)
        s = ''
        for i in range(0,len(fen)):
            if (i)%8 == 0:
                s+='\n'
            else:
                s+=' '
            s+=fen[i]
        print s

    def maps(self,fen):
        #print "before maps"
        self.fen = fen.replace('\n','').replace(' ','')
        #print self.fen
    
    @staticmethod
    def name(i):
        n = 8 - i/8
        a = chr(97+i%8)
        return a+str(n)
    
    @staticmethod
    def eman(s):
        return ord(s[0]) - 97 + (8-int(s[1]))*8
    
    def check_bmove(self):
        fen = self.fen
        fen0= self.fen0
        f0 = ''
        f  = ''
        
        for i in range(0,64):
            if fen[i] == fen0[i]:
                f0+='*'
                f+='*'
            else:
                f0+=fen0[i]
                f +=fen[i]
        print len(f0.replace('\*','')),f0
        print len(f.replace('\*','')),f

        # This part need fix
        for i in range(0,64):
            if fen[i] in string.ascii_lowercase:
                if fen0[i] != fen[i]:
                    left = chess.name(i)
                    
        for i in range(0,64):
            if fen0[i] in string.ascii_lowercase:
                if fen0[i] != fen[i]:
                    right = chess.name(i)
        return right + left

    def recvs(self):
        recv = ''
        while 'move' not in recv:
            recv += self.pp.recv(4096)
            if 'you win' in recv:
                print recv
                self.count+=1
                print "-"*80
                print "[+] Win ! Count : %d" % self.count
                print "-"*80
                recv = ''
                self.moves = ['']
                self.fen  =''
                self.fen0 =''
        print recv
        return recv

    def get_move(self, recv):
        recv = recv.replace('game starts\n','')
        self.maps(recv[0:127])
        if len(self.fen0) == 64:
            mm = self.check_bmove()
            print 'black move '+ mm
            return mm
        return ''

    def move(self,next_move):
        start = chess.eman(next_move[0:2])
        stop  = chess.eman(next_move[2:4])

        # This part need fix
        fen = list(self.fen)
        fen[stop] = fen[start]
        fen[start] = '.'
        
        self.pp.send(next_move+'\n')

        chess.print_fen(''.join(fen))
        
        self.fen0 = ''.join(fen)


class fish():
    def __init__(self):
        self.p=subprocess.Popen(r'stockfish_9_x64.exe',stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,)
        self.p.stdin.write('uci\r\n')
        self.p.stdin.flush()
        s = self.p.stdout.readline()
        while "uciok" not in s:
            s = self.p.stdout.readline()
            
        self.p.stdin.write('isready\r\n')
        self.p.stdin.flush()
        s = self.p.stdout.readline()

        if 'readyok' in s:
            print 'Stockfish is ready'

    def next_move(self, moves):
        position = 'position startpos moves '+' '.join(moves)+'\r\n'
        print position
        self.p.stdin.write(position)
        self.p.stdin.write('go wtime 600000 btime 600000 winc 0 binc 0\r\n')
        self.p.stdin.flush()
        s = self.p.stdout.readline()

        while "bestmove" not in s:
            s = self.p.stdout.readline()
        print s

        return s[9:13]


chs = chess()
fsh = fish()

fen = chs.recvs()

while chs.count < 20:
    bmove = chs.get_move(fen)

    if len(bmove) == 0:
        print 'first move'
    else:
        chs.moves.append(bmove)
        
    wmove = fsh.next_move(chs.moves)
    
    chs.move(wmove)

    chs.moves.append(wmove)

    print chs.moves

    fen = chs.recvs()




